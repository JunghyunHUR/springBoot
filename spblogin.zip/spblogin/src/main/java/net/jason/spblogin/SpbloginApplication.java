package net.jason.spblogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpbloginApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpbloginApplication.class, args);
	}

}
